const {valideNbCharacter} = require('../src/testable2.js');

describe('valideNbCharacter', () => {
    test('Chaîne Invalide', () => {
        expect (valideNbCharacter('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.')).toBe(false);

    });
    test ('Chaîne Valide', () => {
        expect (valideNbCharacter('Lorem ipsum dolor sit amet, consectetur adipiscing elit.')).toBe(true);
    });
});


