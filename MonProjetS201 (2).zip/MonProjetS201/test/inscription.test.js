const { motDePasseValide } = require('../src/inscription2.js');

describe('Vérification du mot de passe', () => {
  test('Le mot de passe doit contenir au moins 8 caractères et une majuscule', () => {
    expect(motDePasseValide('Abcdefgh')).toBe(true);      // valide
    expect(motDePasseValide('abcdefgh')).toBe(false);     // pas de majuscule
    expect(motDePasseValide('Abcdefg')).toBe(false);      // moins de 8 caractères
    expect(motDePasseValide('ABCDEFGH')).toBe(true);      // valide
  });
});