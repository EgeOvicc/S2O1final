const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware : permet de lire les données envoyées depuis un formulaire (POST)
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Sert les fichiers du dossier public (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// Page principale
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


// Route POST : Ajouter un objet à la base JSON
 
app.post('/ajouter-objet', (req, res) => {
  const body = req.body || {};
  const { titre, description, etat, categorie, taille } = body;

  // Vérifie que tous les champs obligatoires sont remplis
  if (!titre || !description || !etat || !categorie) {
    return res.status(400).send("Champs obligatoires manquants.");
  }

  const nouvelObjet = {
    id: Date.now(),
    titre,
    description,
    etat,
    categorie,
    taille,
    photos: []
  };

  const chemin = path.join(__dirname, 'data', 'objet.json');
  let objets = [];

  // Lire le fichier existant si présent
  if (fs.existsSync(chemin)) {
    const contenu = fs.readFileSync(chemin, 'utf-8');
    objets = contenu ? JSON.parse(contenu) : [];
  }

  objets.push(nouvelObjet);
  fs.writeFileSync(chemin, JSON.stringify(objets, null, 2), 'utf-8');

  res.send('Objet ajouté avec succès !');
});


//Route POST : Enregistrer un utilisateur lors de l'inscription

app.post('/inscription', (req, res) => {
  const { pseudo, mail, motdepasse } = req.body;

  // Vérifie que tous les champs sont présents
  if (!pseudo || !mail || !motdepasse) {
    return res.status(400).send("Tous les champs sont requis.");
  }

  const nouvelUtilisateur = {
    id: Date.now(),
    pseudo,
    mail,
    motdepasse
  };

  const chemin = path.join(__dirname, 'data', 'informations.json');
  let utilisateurs = [];

  if (fs.existsSync(chemin)) {
    const contenu = fs.readFileSync(chemin, 'utf-8');
    utilisateurs = contenu ? JSON.parse(contenu) : [];
  }

  utilisateurs.push(nouvelUtilisateur);
  fs.writeFileSync(chemin, JSON.stringify(utilisateurs, null, 2), 'utf-8');

  res.send("Inscription réussie !");
});

// Démarrer le serveur
app.listen(PORT, () => {
  console.log(`Serveur Express actif sur http://localhost:${PORT}`);
});
