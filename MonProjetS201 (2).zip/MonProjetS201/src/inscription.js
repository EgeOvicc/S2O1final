export function motDePasseValide(mdp) {
  return mdp.length >= 8 && /[A-Z]/.test(mdp);
}

