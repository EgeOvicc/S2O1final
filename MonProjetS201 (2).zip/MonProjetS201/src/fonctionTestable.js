export function fonctionTestable(fonction) {
   const regex = /^.{0,200}$/
    return regex.test(fonction);
}

