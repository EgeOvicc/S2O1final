function valideNbCharacter(str) {
    // Verifie si la chaîne de caractères est inferieure à 200
    const regex = /^.{0,200}$/
    return regex.test(str);
}


module.exports.valideNbCharacter = valideNbCharacter;

