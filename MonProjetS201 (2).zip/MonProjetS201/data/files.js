// On importe les fonctions pour lire et écrire dans un fichier
import { readFileSync, writeFileSync, existsSync } from 'fs';

// Chemins vers les fichiers JSON
const cheminObjets = './objet.json';
const cheminUtilisateurs = './data/informations.json';


 // FONCCTIONS POUR LES OBJETS

// Lire tous les objets enregistrés
export function lireObjets() {
  try {
    const contenuFichier = readFileSync(cheminObjets, 'utf-8');
    return JSON.parse(contenuFichier);
  } catch (erreur) {
    console.log("Erreur lors de la lecture du fichier :", erreur);
    return [];
  }
}

// Ajouter un nouvel objet dans le fichier
export function ajouterObjet(nouvelObjet) {
  const objets = lireObjets();
  const nouvelId = objets.length > 0 ? objets[objets.length - 1].id + 1 : 1;

  const objetAAjouter = {
    id: nouvelId,
    titre: nouvelObjet.titre || '',
    description: nouvelObjet.description || '',
    etat: nouvelObjet.etat || '',
    categorie: nouvelObjet.categorie || '',
    taille: nouvelObjet.taille || '',
    photos: nouvelObjet.photos || []
  };

  objets.push(objetAAjouter);

  try {
    writeFileSync(cheminObjets, JSON.stringify(objets, null, 2), 'utf-8');
    console.log("Objet ajouté avec succès !");
  } catch (erreur) {
    console.log("Erreur lors de l'enregistrement de l'objet :", erreur);
  }
}


 // FONCTION POUR LES UTILISATEURS
 
// Ajouter un utilisateur dans informations.json
export function enregistrerUtilisateur(utilisateur) {
  let utilisateurs = [];

  if (existsSync(cheminUtilisateurs)) {
    try {
      const contenu = readFileSync(cheminUtilisateurs, 'utf-8');
      utilisateurs = contenu ? JSON.parse(contenu) : [];
    } catch (erreur) {
      console.log("Erreur lors de la lecture des utilisateurs :", erreur);
    }
  }

  utilisateur.id = Date.now();
  utilisateurs.push(utilisateur);

  try {
    writeFileSync(cheminUtilisateurs, JSON.stringify(utilisateurs, null, 2), 'utf-8');
    console.log("Utilisateur enregistré !");
  } catch (erreur) {
    console.log("Erreur lors de l'enregistrement de l'utilisateur :", erreur);
  }
}
