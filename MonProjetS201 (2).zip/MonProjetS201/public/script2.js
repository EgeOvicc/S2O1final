import { motDePasseValide } from "../src/inscription2.js";

document.addEventListener("DOMContentLoaded", function () {
  const formulaire = document.getElementById("formulaire-inscription");
  const motDePasseInput = document.getElementById("motdepasse");
  const confirmationInput = document.getElementById("confirmation");

  formulaire.addEventListener("submit", function (event) {
    event.preventDefault();

    const motDePasse = motDePasseInput.value;
    const confirmation = confirmationInput.value;

    if (!motDePasseValide(motDePasse)) {
      alert("Le mot de passe doit contenir au moins 8 caractères et une majuscule.");
      return;
    }

    if (motDePasse !== confirmation) {
      alert("La confirmation du mot de passe ne correspond pas.");
      return;
    }

    // Si tout est valide, on peut soumettre le formulaire
    formulaire.submit();
  });
});