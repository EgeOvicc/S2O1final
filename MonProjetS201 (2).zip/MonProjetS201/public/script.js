import {fonctionTestable} from './src/fonctionTestable.js';


document.addEventListener("DOMContentLoaded", function () {
  const selectCategorie = document.getElementById("categorie");
  const sectionTaille = document.getElementById("section-taille");

  selectCategorie.addEventListener("change", () => {
    const valeur = selectCategorie.value;

    if (valeur === "vetements" || valeur === "chaussures") {
      sectionTaille.style.display = "block";
    } else {
      sectionTaille.style.display = "none";
    }
  });
});


document.addEventListener('DOMContentLoaded', function() {
  const btnAjouter = document.querySelector('.bouton-principal');
  const categorieSelect = document.getElementById('categorie');
  const tailleSection = document.getElementById('section-taille');

  // Gére l'affichage du champ taille en fonction de la catégorie
  categorieSelect.addEventListener('change', function() {
    if (this.value === 'vetements' || this.value === 'chaussures') {
      tailleSection.style.display = 'block';
    } else {
      tailleSection.style.display = 'none';
      document.getElementById('taille').value = '';
    }
  });

  btnAjouter.addEventListener('click', function(event) {
    event.preventDefault();

    // Récupére les valeurs
    const titre = document.getElementById('titre').value.trim();
    const description = document.getElementById('description').value.trim();
    const etat = document.getElementById('etat').value;
    const categorie = categorieSelect.value;
    const taille = document.getElementById('taille').value.trim();

    // Validation : si un champ obligatoire est vide, on affiche un message et on arrête
    if (!titre) {
      alert('Merci de saisir un titre.');
      return;
    }
    if (!description) {
      alert('Merci de saisir une description.');
      return;
    }
    if (!fonctionTestable.valideNbCharacter(titre)) {
      alert('La description doit contenir moins de 200 caractères.');
      return;
    }
    if (!etat) {
      alert('Merci de sélectionner un état.');
      return;
    }
    if (!categorie) {
      alert('Merci de sélectionner une catégorie.');
      return;
    }
    if ((categorie === 'vetements' || categorie === 'chaussures') && !taille) {
      alert('Merci de saisir une taille.');
      return;
    }

    // Si on arrive ici, tous les champs obligatoires sont remplis,
    // on affiche la popup succès
    alert('Article ajouté avec succès !');

    // Puis on vide tous les champs
    document.getElementById('titre').value = '';
    document.getElementById('description').value = '';
    document.getElementById('etat').selectedIndex = 0;
    categorieSelect.selectedIndex = 0;
    document.getElementById('taille').value = '';
    tailleSection.style.display = 'none';


  });
});








 


    